import 'dotenv/config';
import express from 'express';
import nodemailer from 'nodemailer';
import logger from '../utils/logger.js';

const router = express.Router();

// Create nodemailer transporter with Hostinger SMTP
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT, 10),
  secure: true, // Use TLS for port 465
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD,
  },
});

router.post('/', async (req, res) => {
  const { name, email, phone, serviceType, message } = req.body;

  // Validate all fields are present and non-empty
  if (!name || typeof name !== 'string' || name.trim() === '') {
    logger.warn('Contact form validation failed: Name is missing or empty');
    return res.status(400).json({ error: 'Name is required and must be non-empty' });
  }

  if (!email || typeof email !== 'string' || email.trim() === '') {
    logger.warn('Contact form validation failed: Email is missing or empty');
    return res.status(400).json({ error: 'Email is required and must be non-empty' });
  }

  if (!phone || typeof phone !== 'string' || phone.trim() === '') {
    logger.warn('Contact form validation failed: Phone is missing or empty');
    return res.status(400).json({ error: 'Phone is required and must be non-empty' });
  }

  if (!serviceType || typeof serviceType !== 'string' || serviceType.trim() === '') {
    logger.warn('Contact form validation failed: Service Type is missing or empty');
    return res.status(400).json({ error: 'Service Type is required and must be non-empty' });
  }

  if (!message || typeof message !== 'string' || message.trim() === '') {
    logger.warn('Contact form validation failed: Message is missing or empty');
    return res.status(400).json({ error: 'Message is required and must be non-empty' });
  }

  const timestamp = new Date().toISOString();

  logger.info(`Contact form submission received from ${email} for service type: ${serviceType}`);
  logger.debug(`Form data - Name: ${name}, Phone: ${phone}, Message length: ${message.length}`);

  const htmlBody = `
    <html>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <h2>New Contact Form Submission</h2>
        <p><strong>Sender Name:</strong> ${name}</p>
        <p><strong>Sender Email:</strong> ${email}</p>
        <p><strong>Sender Phone:</strong> ${phone}</p>
        <p><strong>Service Type:</strong> ${serviceType}</p>
        <p><strong>Timestamp:</strong> ${timestamp}</p>
        <hr>
        <h3>Message Content:</h3>
        <p>${message.replace(/\n/g, '<br>')}</p>
      </body>
    </html>
  `;

  const mailOptions = {
    from: process.env.SMTP_USER,
    to: 'info@expertfixservices.com',
    subject: `New Contact Form Submission from ${name}`,
    html: htmlBody,
  };

  logger.info(`Attempting to send email via SMTP (${process.env.SMTP_HOST}:${process.env.SMTP_PORT}) to info@expertfixservices.com`);

  // Send email - if it fails, throw error so errorMiddleware catches it
  await transporter.sendMail(mailOptions);

  logger.info(`✓ Contact form email successfully sent from ${email} for service type: ${serviceType}`);

  // Only send success response AFTER email is successfully sent
  res.json({ success: true, message: 'Email sent successfully' });
});

export default router;