import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Send, Loader2 } from 'lucide-react';
import apiServerClient from '@/lib/apiServerClient.js';

const formSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email address'),
  phone: z.string().min(10, 'Please enter a valid phone number'),
  serviceType: z.string().min(1, 'Please select a service type'),
  message: z.string().min(10, 'Message must be at least 10 characters'),
});

const ContactForm = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
    reset,
  } = useForm({
    resolver: zodResolver(formSchema),
  });

  const serviceType = watch('serviceType');

  const services = [
    'Handyman Services',
    'Renovations',
    'Painting',
    'Flooring',
    'Plasterboard',
    'Kitchen Installation',
    'Bathroom Renovation',
    'Carpentry',
    'General Repairs',
  ];

  const onSubmit = async (data) => {
    console.log('Form submission triggered. Validated data:', data);
    setIsSubmitting(true);
    
    try {
      const payload = {
        name: data.name,
        email: data.email,
        phone: data.phone,
        serviceType: data.serviceType,
        message: data.message
      };

      console.log('Sending payload to /contact endpoint:', payload);

      const response = await apiServerClient.fetch('/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      console.log('Received response status:', response.status);

      // Parse response data safely
      const responseData = await response.json().catch(() => ({}));
      console.log('Received response data:', responseData);

      if (!response.ok) {
        // Extract error message from backend response (handles both 400 validation and 500 server errors)
        const errorMessage = responseData.error || responseData.message || 'Failed to send message';
        throw new Error(errorMessage);
      }

      // Success toast only triggers AFTER a successful backend response
      toast({
        description: responseData.message || 'Email sent successfully! We will contact you soon.',
      });

      reset();
    } catch (error) {
      console.error('Contact form submission error:', error);
      toast({
        description: error.message || 'Failed to send message. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input
              id="name"
              {...register('name')}
              placeholder="Anika Bergström"
              className="bg-white text-gray-900"
            />
            {errors.name && (
              <p className="text-sm text-destructive">{errors.name.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email Address *</Label>
            <Input
              id="email"
              type="email"
              {...register('email')}
              placeholder="anika@example.com"
              className="bg-white text-gray-900"
            />
            {errors.email && (
              <p className="text-sm text-destructive">{errors.email.message}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number *</Label>
            <Input
              id="phone"
              type="tel"
              {...register('phone')}
              placeholder="+353 87 123 4567"
              className="bg-white text-gray-900"
            />
            {errors.phone && (
              <p className="text-sm text-destructive">{errors.phone.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="serviceType">Service Type *</Label>
            {/* Added shouldValidate: true to ensure mobile selections clear validation errors immediately */}
            <Select onValueChange={(value) => setValue('serviceType', value, { shouldValidate: true })}>
              <SelectTrigger className="bg-white text-gray-900">
                <SelectValue placeholder="Select a service" />
              </SelectTrigger>
              <SelectContent>
                {services.map((service) => (
                  <SelectItem key={service} value={service}>
                    {service}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.serviceType && (
              <p className="text-sm text-destructive">{errors.serviceType.message}</p>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="message">Message *</Label>
          <Textarea
            id="message"
            {...register('message')}
            placeholder="Tell us about your project..."
            rows={5}
            className="bg-white text-gray-900"
          />
          {errors.message && (
            <p className="text-sm text-destructive">{errors.message.message}</p>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            type="submit"
            disabled={isSubmitting}
            className="bg-accent hover:bg-accent/90 text-white transition-all duration-200 active:scale-[0.98] flex-1"
          >
            {isSubmitting ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Send className="w-4 h-4 mr-2" />
            )}
            {isSubmitting ? 'Sending...' : 'Send Message'}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ContactForm;