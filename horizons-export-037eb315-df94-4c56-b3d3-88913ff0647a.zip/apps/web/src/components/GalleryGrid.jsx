import React, { useState } from 'react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, CheckCircle } from 'lucide-react';
import ProjectCard from './ProjectCard.jsx';

const GalleryGrid = ({ projects }) => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [filter, setFilter] = useState('All');

  const categories = ['All', ...new Set(projects.map(p => p.category))];

  const filteredProjects = filter === 'All' 
    ? projects 
    : projects.filter(p => p.category === filter);

  return (
    <div className="space-y-12">
      <div className="flex flex-wrap gap-3 justify-center">
        {categories.map((category) => (
          <Button
            key={category}
            onClick={() => setFilter(category)}
            variant={filter === category ? 'default' : 'outline'}
            className={`transition-all duration-300 rounded-full px-8 py-6 text-sm font-semibold ${
              filter === category
                ? 'bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20 border-primary'
                : 'border-primary/20 hover:border-primary/50 bg-card text-foreground hover:text-primary'
            }`}
          >
            {category}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
        {filteredProjects.map((project, index) => (
          <div key={project.id} onClick={() => setSelectedImage(project)} className="h-full">
            <ProjectCard {...project} index={index} />
          </div>
        ))}
      </div>

      <Dialog open={!!selectedImage} onOpenChange={(open) => !open && setSelectedImage(null)}>
        <DialogContent className="max-w-5xl p-0 overflow-hidden bg-card border-primary/20 rounded-2xl shadow-2xl">
          {selectedImage && (
            <div className="flex flex-col md:flex-row h-full max-h-[85vh]">
              <div className="relative w-full md:w-3/5 bg-muted flex items-center justify-center overflow-hidden">
                <img
                  src={selectedImage.image}
                  alt={selectedImage.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="w-full md:w-2/5 p-8 md:p-10 bg-card flex flex-col overflow-y-auto">
                <div className="mb-6">
                  <Badge className="bg-primary/10 text-primary border-primary/20 mb-4 font-semibold px-3 py-1">
                    {selectedImage.category}
                  </Badge>
                  <DialogTitle className="text-3xl font-bold text-foreground mb-4 text-balance leading-tight">
                    {selectedImage.title}
                  </DialogTitle>
                  <div className="flex items-center text-sm text-muted-foreground font-medium">
                    <Calendar className="w-4 h-4 mr-2 text-primary" />
                    {selectedImage.date || 'Completed Recently'}
                  </div>
                </div>
                
                <div className="w-12 h-1 bg-primary mb-6 rounded-full"></div>
                
                <p className="text-base text-muted-foreground leading-relaxed mb-8">
                  {selectedImage.description}
                </p>

                <div className="mt-auto space-y-4">
                  <h4 className="font-semibold text-foreground flex items-center">
                    <CheckCircle className="w-5 h-5 text-primary mr-2" />
                    Project Highlights
                  </h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-center">• Premium materials used</li>
                    <li className="flex items-center">• Completed on schedule</li>
                    <li className="flex items-center">• Fully insured workmanship</li>
                  </ul>
                  
                  <div className="pt-8">
                    <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-6 text-lg font-semibold shadow-lg shadow-primary/20" onClick={() => window.location.href = '/contact'}>
                      Start Similar Project
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default GalleryGrid;