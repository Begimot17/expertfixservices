import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, MessageCircle, MapPin, Shield, Award } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-background border-t border-primary/20 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div className="space-y-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center shadow-lg shadow-primary/20">
                <span className="text-primary-foreground font-bold text-xl">EF</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-foreground tracking-tight">Expert Fix</span>
                <span className="text-[10px] text-primary font-medium tracking-widest uppercase">Services</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Premium construction and handyman services across Ireland. Delivering excellence, reliability, and guaranteed quality for over 20 years.
            </p>
            <div className="flex items-center space-x-4 text-sm text-primary font-medium">
              <span className="flex items-center"><Shield className="w-4 h-4 mr-1" /> Fully Insured</span>
              <span className="flex items-center"><Award className="w-4 h-4 mr-1" /> Guaranteed</span>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
              <span className="w-8 h-[2px] bg-primary mr-3"></span>
              Quick Links
            </h3>
            <nav className="space-y-3">
              {['Home', 'Services', 'Portfolio', 'About', 'Contact'].map((item) => (
                <Link 
                  key={item} 
                  to={item === 'Home' ? '/' : item === 'Portfolio' ? '/work' : `/${item.toLowerCase()}`} 
                  className="block text-sm text-muted-foreground hover:text-primary transition-colors duration-200 w-fit"
                >
                  {item}
                </Link>
              ))}
            </nav>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
              <span className="w-8 h-[2px] bg-primary mr-3"></span>
              Contact Us
            </h3>
            <div className="space-y-4">
              <a href="https://wa.me/353874919556" target="_blank" rel="noopener noreferrer" className="flex items-start space-x-3 text-sm text-muted-foreground hover:text-primary transition-colors duration-200 group">
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <MessageCircle className="w-4 h-4 text-primary" />
                </div>
                <div className="flex flex-col pt-1.5">
                  <span className="font-medium text-foreground">WhatsApp</span>
                  <span>Message us 24/7</span>
                </div>
              </a>
              <a href="mailto:info@expertfixservices.com" className="flex items-start space-x-3 text-sm text-muted-foreground hover:text-primary transition-colors duration-200 group">
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <Mail className="w-4 h-4 text-primary" />
                </div>
                <div className="flex flex-col pt-1.5">
                  <span className="font-medium text-foreground">Email</span>
                  <span>info@expertfixservices.com</span>
                </div>
              </a>
              <div className="flex items-start space-x-3 text-sm text-muted-foreground">
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                  <MapPin className="w-4 h-4 text-primary" />
                </div>
                <div className="flex flex-col pt-1.5">
                  <span className="font-medium text-foreground">Location</span>
                  <span>Serving all of Ireland</span>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
              <span className="w-8 h-[2px] bg-primary mr-3"></span>
              Legal
            </h3>
            <nav className="space-y-3">
              <Link to="/privacy-policy" className="block text-sm text-muted-foreground hover:text-primary transition-colors duration-200 w-fit">
                Privacy Policy
              </Link>
              <Link to="/terms-of-services" className="block text-sm text-muted-foreground hover:text-primary transition-colors duration-200 w-fit">
                Terms of Services
              </Link>
            </nav>
          </div>
        </div>

        <div className="pt-8 border-t border-primary/10 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-sm text-muted-foreground">
            © {currentYear} Expert Fix Services. All rights reserved.
          </p>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <span>Premium Construction Services Ireland</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;