import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, ArrowUpRight } from 'lucide-react';
import { motion } from 'framer-motion';

const ProjectCard = ({ image, title, category, description, date, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="h-full"
    >
      <Card className="overflow-hidden group cursor-pointer bg-card border-primary/20 hover:border-primary/50 shadow-lg hover:shadow-2xl hover:shadow-primary/20 transition-all duration-500 h-full flex flex-col rounded-xl">
        <div className="relative aspect-[4/3] overflow-hidden bg-muted">
          <img
            src={image}
            alt={title}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-500" />
          
          <div className="absolute top-4 right-4">
            <Badge className="bg-primary text-primary-foreground border-none font-semibold shadow-lg backdrop-blur-sm">
              {category}
            </Badge>
          </div>
          
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500">
            <div className="w-16 h-16 rounded-full bg-primary/90 flex items-center justify-center text-primary-foreground transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
              <ArrowUpRight className="w-8 h-8" />
            </div>
          </div>
        </div>
        
        <div className="p-6 flex-grow flex flex-col justify-between relative z-10 bg-card">
          <div>
            <div className="flex items-center text-xs text-primary font-medium mb-3 tracking-wider uppercase">
              <Calendar className="w-3 h-3 mr-1.5" />
              {date || 'Recent Project'}
            </div>
            <h3 className="text-xl font-bold text-foreground mb-3 text-balance group-hover:text-primary transition-colors duration-300 leading-tight">{title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3">{description}</p>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export default ProjectCard;