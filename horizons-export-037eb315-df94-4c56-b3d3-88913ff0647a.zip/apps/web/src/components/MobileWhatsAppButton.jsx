import React from 'react';
import { MessageCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const MobileWhatsAppButton = () => {
  return (
    <motion.a
      href="https://wa.me/353874919556"
      target="_blank"
      rel="noopener noreferrer"
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="md:hidden fixed bottom-6 right-6 z-50 w-[60px] h-[60px] bg-primary text-primary-foreground rounded-full shadow-2xl flex items-center justify-center animate-pulse hover:animate-none"
      aria-label="Message us on WhatsApp"
    >
      <MessageCircle className="w-8 h-8" />
    </motion.a>
  );
};

export default MobileWhatsAppButton;