import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Shield, CheckCircle, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const ServiceCard = ({ icon: Icon, title, description, features, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="h-full"
    >
      <Card className="h-full bg-card border-primary/20 hover:border-primary/50 shadow-lg hover:shadow-2xl hover:shadow-primary/10 transition-all duration-500 hover:-translate-y-2 group flex flex-col overflow-hidden">
        <div className="h-2 w-full bg-gradient-to-r from-primary/40 via-primary to-primary/40 transform origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
        <CardContent className="p-8 flex flex-col h-full">
          <div className="flex justify-between items-start mb-6">
            <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center group-hover:bg-primary transition-colors duration-500 shadow-inner">
              <Icon className="w-8 h-8 text-primary group-hover:text-primary-foreground transition-colors duration-500" />
            </div>
            <div className="flex flex-col gap-2 items-end">
              <Badge variant="outline" className="border-primary/30 text-primary bg-primary/5 flex items-center gap-1">
                <Shield className="w-3 h-3" /> Insured
              </Badge>
            </div>
          </div>
          
          <h3 className="text-2xl font-bold text-foreground mb-4 text-balance group-hover:text-primary transition-colors duration-300">{title}</h3>
          <p className="text-base text-muted-foreground leading-relaxed mb-6 flex-grow">{description}</p>
          
          {features && (
            <ul className="space-y-3 mb-8">
              {features.slice(0, 3).map((feature, idx) => (
                <li key={idx} className="flex items-start text-sm text-foreground/80">
                  <CheckCircle className="w-4 h-4 text-primary mr-2 mt-0.5 flex-shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          )}
          
          <div className="mt-auto pt-4 border-t border-primary/10">
            <Link to="/contact" className="w-full">
              <Button variant="ghost" className="w-full justify-between group/btn hover:bg-primary hover:text-primary-foreground text-primary font-semibold border border-primary/20">
                Get Free Quote
                <ArrowRight className="w-4 h-4 transform group-hover/btn:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ServiceCard;