import React from 'react';
import { motion } from 'framer-motion';

const BenefitCard = ({ icon: Icon, title, description, number, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="flex items-start space-x-6"
    >
      <div className="relative flex-shrink-0">
        <span className="text-6xl font-bold text-accent/20" style={{ letterSpacing: '-0.02em' }}>
          {number}
        </span>
        <div className="absolute top-2 left-12 w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
          <Icon className="w-6 h-6 text-accent" />
        </div>
      </div>
      <div className="pt-2">
        <h3 className="text-xl font-semibold text-foreground mb-2 text-balance">{title}</h3>
        <p className="text-sm text-muted-foreground leading-relaxed max-w-prose">{description}</p>
      </div>
    </motion.div>
  );
};

export default BenefitCard;