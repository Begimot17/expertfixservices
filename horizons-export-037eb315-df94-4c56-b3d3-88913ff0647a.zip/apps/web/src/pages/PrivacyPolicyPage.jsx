import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const PrivacyPolicyPage = () => {
  const sections = [
    {
      title: 'Introduction',
      content: 'At Expert Fix Services, we take your privacy seriously. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services. Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the site.'
    },
    {
      title: 'Information We Collect',
      content: 'We may collect information about you in a variety of ways. The information we may collect on the Site includes personal data, such as your name, shipping address, email address, and telephone number, and demographic information, such as your age, gender, hometown, and interests, that you voluntarily give to us when you register with the Site or when you choose to participate in various activities related to the Site.'
    },
    {
      title: 'How We Use Your Information',
      content: 'Having accurate information about you permits us to provide you with a smooth, efficient, and customized experience. Specifically, we may use information collected about you via the Site to: create and manage your account, deliver targeted advertising, email you regarding your account or order, fulfill and manage purchases, orders, payments, and other transactions related to the Site, and respond to customer service requests.'
    },
    {
      title: 'Data Security',
      content: 'We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.'
    },
    {
      title: 'Your Rights',
      content: 'Depending on your location, you may have certain rights regarding your personal information, including the right to access, correct, update, or request deletion of your personal information. You can exercise these rights by contacting us using the contact information provided below.'
    },
    {
      title: 'Contact Us',
      content: 'If you have questions or comments about this Privacy Policy, please contact us at: info@expertfixservices.com or by mail at our registered business address.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Privacy Policy - Expert Fix Services</title>
        <meta name="description" content="Read our privacy policy to understand how Expert Fix Services collects, uses, and protects your personal information." />
      </Helmet>

      <Header />

      <main className="pt-24 pb-20 bg-muted/30 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-12 text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance" style={{ letterSpacing: '-0.02em' }}>
              Privacy Policy
            </h1>
            <p className="text-lg text-muted-foreground">
              Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
            </p>
          </motion.div>

          <div className="space-y-8">
            {sections.map((section, index) => (
              <motion.div
                key={section.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="rounded-xl shadow-lg border-border/50 overflow-hidden">
                  <CardHeader className="bg-muted/50 py-6 px-6 md:px-8 border-b border-border/50">
                    <CardTitle className="text-2xl font-semibold text-foreground">
                      {section.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="py-8 px-6 md:px-8">
                    <p className="text-base text-muted-foreground leading-relaxed max-w-prose">
                      {section.content}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
};

export default PrivacyPolicyPage;