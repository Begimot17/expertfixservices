import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Wrench, PaintBucket, Hammer, Hammer as Drill, Home, Bath, UtensilsCrossed, Ruler, Settings } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ServiceCard from '@/components/ServiceCard.jsx';

const ServicesPage = () => {
  const services = [
    {
      icon: Home,
      title: 'Premium Renovations',
      description: 'Complete home transformations tailored to your lifestyle. We manage every aspect from structural changes to final premium finishes, ensuring a seamless experience.',
      features: [
        'Full property remodeling',
        'Structural alterations & extensions',
        'Dedicated project management',
        'Premium material sourcing',
      ],
    },
    {
      icon: UtensilsCrossed,
      title: 'Bespoke Kitchens',
      description: 'Luxury kitchen installations designed for modern living. We handle cabinetry, premium countertops, integrated appliances, and flawless tiling.',
      features: [
        'Custom cabinetry fitting',
        'Granite & quartz countertops',
        'Integrated appliance setup',
        'Plumbing & electrical integration',
      ],
    },
    {
      icon: Bath,
      title: 'Luxury Bathrooms',
      description: 'Transform your bathroom into a spa-like retreat. Expert waterproofing, high-end fixture installation, and precision tiling for a flawless finish.',
      features: [
        'Complete bathroom refits',
        'Walk-in shower installations',
        'Premium tiling & waterproofing',
        'Modern fixture integration',
      ],
    },
    {
      icon: PaintBucket,
      title: 'High-End Painting',
      description: 'Flawless interior and exterior finishes using premium, durable materials. Meticulous surface preparation guarantees a perfect, long-lasting result.',
      features: [
        'Interior & exterior painting',
        'Meticulous surface prep',
        'Premium low-VOC paints',
        'Detailed trim & woodwork',
      ],
    },
    {
      icon: Ruler,
      title: 'Premium Flooring',
      description: 'Expert installation of high-quality flooring solutions. From solid hardwood to luxury vinyl and natural stone, laid with absolute precision.',
      features: [
        'Solid & engineered hardwood',
        'Luxury vinyl tile (LVT)',
        'Natural stone & ceramic',
        'Subfloor leveling & prep',
      ],
    },
    {
      icon: Hammer,
      title: 'Custom Carpentry',
      description: 'Bespoke woodwork crafted to your exact specifications. Built-in wardrobes, custom shelving, and architectural details that elevate your space.',
      features: [
        'Built-in wardrobes & storage',
        'Custom shelving units',
        'Architectural trim & molding',
        'Bespoke furniture pieces',
      ],
    },
    {
      icon: Drill,
      title: 'Expert Plastering',
      description: 'Precision drywall installation and skimming for perfectly smooth, flawless surfaces ready for high-end decoration.',
      features: [
        'Drywall installation',
        'Expert skimming & finishing',
        'Partition wall construction',
        'Soundproofing solutions',
      ],
    },
    {
      icon: Wrench,
      title: 'Professional Handyman',
      description: 'Reliable, high-quality maintenance and repair services for your property. We handle complex fixes with the same care as major renovations.',
      features: [
        'Complex property repairs',
        'Fixture & fitting installation',
        'Preventative maintenance',
        'Door & window adjustments',
      ],
    },
    {
      icon: Settings,
      title: 'General Maintenance',
      description: 'Comprehensive upkeep for residential and commercial properties. Ensuring your investment remains in pristine condition year-round.',
      features: [
        'Commercial property upkeep',
        'Emergency repair services',
        'Leak detection & fixes',
        'Routine property checks',
      ],
    },
  ];

  return (
    <>
      <Helmet>
        <title>Premium Services - Expert Fix Services Ireland</title>
        <meta name="description" content="Explore our premium construction and handyman services. Fully insured, professional renovations, painting, flooring, and bespoke carpentry across Ireland." />
      </Helmet>

      <Header />

      <main className="pt-24">
        <section className="py-20 bg-background relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-background to-background pointer-events-none"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto"
            >
              <h1 className="text-sm font-bold text-primary tracking-widest uppercase mb-4">Expertise & Reliability</h1>
              <h2 className="text-5xl md:text-6xl font-bold text-foreground mb-6 text-balance leading-tight">
                Our Premium Services
              </h2>
              <p className="text-xl text-muted-foreground leading-relaxed font-light">
                Delivering uncompromising quality and craftsmanship for every project, backed by our comprehensive guarantee and full insurance.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-16 bg-card border-t border-primary/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service, index) => (
                <ServiceCard key={service.title} {...service} index={index} />
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-background relative">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="bg-card p-12 rounded-3xl border border-primary/20 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary/40 via-primary to-primary/40"></div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6 text-balance">
                Don't see what you're looking for?
              </h2>
              <p className="text-lg text-muted-foreground mb-10 leading-relaxed max-w-2xl mx-auto">
                We offer custom solutions tailored to your specific property needs. Contact our experts to discuss your unique project requirements.
              </p>
              <a href="/contact">
                <button className="bg-primary hover:bg-primary/90 text-primary-foreground px-10 py-5 rounded-xl font-semibold transition-all duration-300 shadow-lg shadow-primary/20 hover:shadow-primary/40 active:scale-[0.98] text-lg">
                  Discuss Your Project
                </button>
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default ServicesPage;