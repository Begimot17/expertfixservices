import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MessageCircle, Mail, Shield, Zap, Award } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ContactForm from '@/components/ContactForm.jsx';

const ContactPage = () => {
  return (
    <>
      <Helmet>
        <title>Contact Us - Get a Free Quote | Expert Fix Services</title>
        <meta name="description" content="Get your free quote in 24 hours. Message Expert Fix Services on WhatsApp or email us for premium construction and handyman services in Ireland." />
      </Helmet>

      <Header />

      <main className="pt-24">
        <section className="py-20 bg-background relative overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/15 via-background to-background pointer-events-none"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto"
            >
              <h1 className="text-sm font-bold text-primary tracking-widest uppercase mb-4">Fast Response & Professional Service</h1>
              <h2 className="text-5xl md:text-6xl font-bold text-foreground mb-6 text-balance leading-tight">
                Get Your Free Quote Today
              </h2>
              <p className="text-xl text-muted-foreground leading-relaxed font-light mb-10">
                Ready to transform your space? Reach out to our experts and receive a detailed, no-obligation quote within 24 hours.
              </p>
              
              <div className="flex justify-center gap-6 mb-12">
                <span className="flex items-center text-sm font-medium text-foreground/80 bg-card px-4 py-2 rounded-full border border-primary/20">
                  <Shield className="w-4 h-4 text-primary mr-2" /> Fully Insured
                </span>
                <span className="flex items-center text-sm font-medium text-foreground/80 bg-card px-4 py-2 rounded-full border border-primary/20">
                  <Award className="w-4 h-4 text-primary mr-2" /> Professional
                </span>
                <span className="flex items-center text-sm font-medium text-foreground/80 bg-card px-4 py-2 rounded-full border border-primary/20">
                  <Zap className="w-4 h-4 text-primary mr-2" /> Fast Response
                </span>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="py-12 bg-card border-y border-primary/10">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Primary CTA: WhatsApp */}
              <motion.a
                href="https://wa.me/353874919556"
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="flex flex-col items-center justify-center p-10 bg-primary rounded-2xl shadow-xl shadow-primary/20 hover:shadow-2xl hover:shadow-primary/40 hover:-translate-y-1 transition-all duration-300 group text-center"
              >
                <div className="w-20 h-20 bg-primary-foreground/10 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500">
                  <MessageCircle className="w-10 h-10 text-primary-foreground" />
                </div>
                <h3 className="text-2xl font-bold text-primary-foreground mb-2">Message on WhatsApp</h3>
                <p className="text-primary-foreground/80 font-medium">Fastest response time. Chat with us directly.</p>
              </motion.a>

              {/* Secondary CTA: Email */}
              <motion.a
                href="mailto:info@expertfixservices.com"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="flex flex-col items-center justify-center p-10 bg-background rounded-2xl border border-primary/20 hover:border-primary/50 shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group text-center"
              >
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500">
                  <Mail className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">Send an Email</h3>
                <p className="text-muted-foreground font-medium">info@expertfixservices.com</p>
              </motion.a>
            </div>
          </div>
        </section>

        <section className="py-24 bg-background">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
                Or Send an Inquiry
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Fill out the form below with your project details and we'll get back to you.
              </p>
            </div>

            <div className="bg-card p-8 md:p-10 rounded-3xl shadow-2xl border border-primary/20">
              <ContactForm />
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default ContactPage;