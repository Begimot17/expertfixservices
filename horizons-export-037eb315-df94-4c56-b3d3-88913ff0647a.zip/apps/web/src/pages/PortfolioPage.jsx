import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MapPin } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import GalleryGrid from '@/components/GalleryGrid.jsx';

const PortfolioPage = () => {
  const projects = [
    {
      id: 1,
      image: 'https://horizons-cdn.hostinger.com/037eb315-df94-4c56-b3d3-88913ff0647a/2e1c117641b21ee2d2d33ca020ee6381.jpg',
      title: 'Luxury Kitchen Remodel',
      category: 'Renovations',
      date: 'March 2026',
      description: 'Contemporary kitchen with black cabinetry, marble backsplash, white countertops, and recessed ceiling lights',
    },
    {
      id: 2,
      image: 'https://horizons-cdn.hostinger.com/037eb315-df94-4c56-b3d3-88913ff0647a/53caba0c18c9545b6b6fdc3ee7846d93.jpg',
      title: 'Modern Bathroom Retreat',
      category: 'Bathroom',
      date: 'February 2026',
      description: 'Modern bathroom with marble tiles, black fixtures, glass shower enclosure, and wooden vanity',
    },
    {
      id: 3,
      image: 'https://horizons-cdn.hostinger.com/037eb315-df94-4c56-b3d3-88913ff0647a/4c1fb8273da2b0c2bfdfd46c92c1b640.jpg',
      title: 'Bespoke Living Space',
      category: 'Carpentry',
      date: 'January 2026',
      description: 'Luxury walk-in closet with dark wood shelving, recessed lighting, and wooden flooring',
    },
    {
      id: 4,
      image: 'https://horizons-cdn.hostinger.com/037eb315-df94-4c56-b3d3-88913ff0647a/2d70dd6bdfa9736447b7f096e1c00d3d.jpg',
      title: 'Contemporary Open Plan',
      category: 'Renovations',
      date: 'December 2025',
      description: 'Construction site with exposed brick, wooden beams, and renovation in progress',
    },
  ];

  const serviceAreas = [
    'Dublin', 'Cork', 'Galway', 'Limerick', 
    'Waterford', 'Kilkenny', 'Wexford', 'Kildare', 
    'Meath', 'Wicklow', 'Louth', 'Carlow'
  ];

  return (
    <>
      <Helmet>
        <title>Our Work - Premium Portfolio | Expert Fix Services</title>
        <meta name="description" content="View our portfolio of premium construction, renovation, and carpentry projects across Ireland. See the quality of Expert Fix Services." />
      </Helmet>

      <Header />

      <main className="pt-24">
        <section className="py-20 bg-background relative overflow-hidden">
          <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-primary/10 via-background to-background pointer-events-none"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto"
            >
              <h1 className="text-sm font-bold text-primary tracking-widest uppercase mb-4">Quality & Expertise</h1>
              <h2 className="text-5xl md:text-6xl font-bold text-foreground mb-6 text-balance leading-tight">
                Our Recent Projects
              </h2>
              <p className="text-xl text-muted-foreground leading-relaxed font-light">
                Explore a selection of our premium construction and renovation projects. Every detail executed with precision and care.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-16 bg-card border-t border-primary/10 min-h-[60vh]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <GalleryGrid projects={projects} />
          </div>
        </section>

        {/* Service Areas Section */}
        <section className="py-24 bg-background border-t border-primary/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-sm font-bold text-primary tracking-widest uppercase mb-3">Coverage</h2>
              <h3 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
                Our Service Areas
              </h3>
              <p className="mt-4 text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Proudly delivering premium construction and renovation services to homes and businesses across these Irish cities and counties.
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {serviceAreas.map((city, index) => (
                <motion.div
                  key={city}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  className="bg-card border border-primary/20 rounded-xl p-6 flex items-center space-x-4 hover:border-primary/50 shadow-md hover:shadow-xl hover:shadow-primary/10 hover:-translate-y-1 transition-all duration-300 group cursor-default"
                >
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary transition-colors duration-300 flex-shrink-0">
                    <MapPin className="w-6 h-6 text-primary group-hover:text-primary-foreground transition-colors duration-300" />
                  </div>
                  <span className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors duration-300">
                    {city}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default PortfolioPage;