import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const TermsOfServicesPage = () => {
  const sections = [
    {
      title: 'Acceptance of Terms',
      content: 'By accessing and using the services provided by Expert Fix Services, you accept and agree to be bound by the terms and provision of this agreement. In addition, when using these particular services, you shall be subject to any posted guidelines or rules applicable to such services.'
    },
    {
      title: 'Services Description',
      content: 'Expert Fix Services provides construction, renovation, and general handyman services. We reserve the right to modify, suspend or discontinue, temporarily or permanently, the services (or any part thereof) with or without notice at any time. You agree that we shall not be liable to you or to any third party for any modification, suspension or discontinuance of the services.'
    },
    {
      title: 'User Responsibilities',
      content: 'You agree to use our services only for lawful purposes and in a way that does not infringe the rights of, restrict or inhibit anyone else\'s use and enjoyment of the website. Prohibited behavior includes harassing or causing distress or inconvenience to any person, transmitting obscene or offensive content or disrupting the normal flow of dialogue within our website.'
    },
    {
      title: 'Limitation of Liability',
      content: 'In no event shall Expert Fix Services, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.'
    },
    {
      title: 'Intellectual Property',
      content: 'The Service and its original content, features and functionality are and will remain the exclusive property of Expert Fix Services and its licensors. The Service is protected by copyright, trademark, and other laws of both the Ireland and foreign countries. Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of Expert Fix Services.'
    },
    {
      title: 'Changes to Terms',
      content: 'We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.'
    },
    {
      title: 'Contact Information',
      content: 'If you have any questions about these Terms, please contact us at info@expertfixservices.com.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Terms of Services - Expert Fix Services</title>
        <meta name="description" content="Read the terms of service for Expert Fix Services. Understand your rights and responsibilities when using our construction and handyman services." />
      </Helmet>

      <Header />

      <main className="pt-24 pb-20 bg-muted/30 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-12 text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance" style={{ letterSpacing: '-0.02em' }}>
              Terms of Services
            </h1>
            <p className="text-lg text-muted-foreground">
              Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
            </p>
          </motion.div>

          <div className="space-y-8">
            {sections.map((section, index) => (
              <motion.div
                key={section.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="rounded-xl shadow-lg border-border/50 overflow-hidden">
                  <CardHeader className="bg-muted/50 py-6 px-6 md:px-8 border-b border-border/50">
                    <CardTitle className="text-2xl font-semibold text-foreground">
                      {section.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="py-8 px-6 md:px-8">
                    <p className="text-base text-muted-foreground leading-relaxed max-w-prose">
                      {section.content}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
};

export default TermsOfServicesPage;