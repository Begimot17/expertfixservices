import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Target, Heart, Users, Award, MapPin } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const AboutPage = () => {
  const team = [
    {
      name: 'Liam O\'Connor',
      role: 'Founder & Lead Contractor',
      initials: 'LO',
      color: 'bg-accent',
    },
    {
      name: 'Siobhan Murphy',
      role: 'Project Manager',
      initials: 'SM',
      color: 'bg-primary',
    },
    {
      name: 'Declan Walsh',
      role: 'Master Carpenter',
      initials: 'DW',
      color: 'bg-accent',
    },
    {
      name: 'Aoife Kelly',
      role: 'Interior Designer',
      initials: 'AK',
      color: 'bg-primary',
    },
  ];

  const values = [
    {
      icon: Target,
      title: 'Quality First',
      description: 'We never compromise on the quality of our work. Every project receives the same meticulous attention to detail.',
    },
    {
      icon: Heart,
      title: 'Customer Focused',
      description: 'Your satisfaction drives everything we do. We listen, adapt, and deliver exactly what you need.',
    },
    {
      icon: Users,
      title: 'Skilled Team',
      description: 'Our experienced professionals bring decades of combined expertise to every project.',
    },
    {
      icon: Award,
      title: 'Proven Excellence',
      description: 'Consistent 5-star reviews and repeat customers demonstrate our commitment to excellence.',
    },
  ];

  const serviceAreas = [
    'Dublin',
    'Cork',
    'Galway',
    'Limerick',
    'Waterford',
    'Kilkenny',
    'Wexford',
    'Kildare',
    'Meath',
    'Wicklow',
    'Louth',
    'Carlow',
  ];

  return (
    <>
      <Helmet>
        <title>About Us - Expert Fix Services Ireland</title>
        <meta name="description" content="Learn about Expert Fix Services - 20+ years of professional construction and handyman services across Ireland. Meet our team and discover our commitment to quality." />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-20 bg-primary text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance" style={{ letterSpacing: '-0.02em' }}>
                About Expert Fix Services
              </h1>
              <p className="text-xl text-white/90 max-w-3xl mx-auto leading-relaxed">
                Building trust through quality workmanship since 2003
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6 text-balance" style={{ letterSpacing: '-0.02em' }}>
                Our Story
              </h2>
              <div className="space-y-4 text-base text-muted-foreground leading-relaxed">
                <p>
                  Expert Fix Services was founded in 2003 with a simple mission: to provide honest, reliable construction and handyman services to homeowners and businesses across Ireland. What started as a one-person operation has grown into a trusted team of skilled professionals.
                </p>
                <p>
                  Over the past two decades, we have completed thousands of projects ranging from minor repairs to major renovations. Our reputation is built on quality workmanship, transparent pricing, and genuine care for our clients and their properties.
                </p>
                <p>
                  Today, we serve communities throughout Ireland, bringing the same dedication and attention to detail to every project, whether it is fixing a leaky tap or renovating an entire home.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance" style={{ letterSpacing: '-0.02em' }}>
                Our Values
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                The principles that guide everything we do
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="h-full border-border shadow-lg hover:shadow-xl transition-shadow duration-300">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center flex-shrink-0">
                          <value.icon className="w-6 h-6 text-accent" />
                        </div>
                        <div>
                          <h3 className="text-xl font-semibold text-foreground mb-2 text-balance">
                            {value.title}
                          </h3>
                          <p className="text-sm text-muted-foreground leading-relaxed">
                            {value.description}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance" style={{ letterSpacing: '-0.02em' }}>
                Meet Our Team
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Experienced professionals dedicated to your project
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {team.map((member, index) => (
                <motion.div
                  key={member.name}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                >
                  <Card className="border-border shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <CardContent className="p-6 text-center">
                      <div className={`w-24 h-24 ${member.color} rounded-xl flex items-center justify-center mx-auto mb-4`}>
                        <span className="text-2xl font-bold text-white">
                          {member.initials}
                        </span>
                      </div>
                      <h3 className="text-lg font-semibold text-foreground mb-1">
                        {member.name}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {member.role}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-background border-t border-primary/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <div className="flex items-center justify-center space-x-3 mb-4">
                <MapPin className="w-8 h-8 text-primary" />
                <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance" style={{ letterSpacing: '-0.02em' }}>
                  Service Coverage
                </h2>
              </div>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                We proudly serve communities across Ireland
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {serviceAreas.map((area, index) => (
                <motion.div
                  key={area}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  className="bg-card border border-primary/20 rounded-xl p-6 flex items-center space-x-4 hover:border-primary/50 shadow-md hover:shadow-xl hover:shadow-primary/10 hover:-translate-y-1 transition-all duration-300 group cursor-default"
                >
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary transition-colors duration-300 flex-shrink-0">
                    <MapPin className="w-6 h-6 text-primary group-hover:text-primary-foreground transition-colors duration-300" />
                  </div>
                  <span className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors duration-300">
                    {area}
                  </span>
                </motion.div>
              ))}
            </div>
            
            <p className="text-center text-sm text-muted-foreground mt-12">
              And surrounding areas throughout Ireland
            </p>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default AboutPage;