import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, MessageCircle, Shield, Award, Zap, CheckCircle, Wrench, Home, PaintBucket } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ServiceCard from '@/components/ServiceCard.jsx';
import TestimonialCard from '@/components/TestimonialCard.jsx';
import ContactForm from '@/components/ContactForm.jsx';

const HomePage = () => {
  const trustElements = [
    { icon: Award, text: '20+ Years Experience' },
    { icon: Shield, text: 'Fully Insured' },
    { icon: Zap, text: 'Fast Response (24h)' },
    { icon: CheckCircle, text: 'Quality Guarantee' },
  ];

  const whyChooseUs = [
    { title: 'Reliable & On Time', desc: 'We respect your schedule and always arrive when promised.' },
    { title: 'Transparent Pricing', desc: 'No hidden fees. You know exactly what you pay for.' },
    { title: 'Skilled Professionals', desc: 'Our team consists of vetted, experienced tradespeople.' },
    { title: 'Guaranteed Results', desc: 'We stand by our work with comprehensive warranties.' },
    { title: 'Free Quote in 24h', desc: 'Fast, detailed estimates to get your project started.' },
  ];

  const topServices = [
    {
      icon: Home,
      title: 'Premium Renovations',
      description: 'Complete home transformations tailored to your lifestyle. From concept to flawless execution.',
      features: ['Full home remodeling', 'Structural alterations', 'Project management'],
    },
    {
      icon: Wrench,
      title: 'Expert Handyman',
      description: 'Professional maintenance and repair services for your property. No job is too complex.',
      features: ['Precision repairs', 'Fixture installations', 'Property maintenance'],
    },
    {
      icon: PaintBucket,
      title: 'High-End Painting',
      description: 'Flawless interior and exterior finishes using premium materials for lasting beauty.',
      features: ['Interior & exterior', 'Surface preparation', 'Color consultation'],
    },
  ];

  const testimonials = [
    {
      name: 'Declan O\'Sullivan',
      role: 'Homeowner, Dublin',
      quote: 'Expert Fix Services completely transformed our ground floor. The attention to detail and professionalism was outstanding. Highly recommend their premium service.',
      rating: 5,
    },
    {
      name: 'Sarah Gallagher',
      role: 'Property Investor, Cork',
      quote: 'I rely on them for all my properties. They are fast, fully insured, and the quality of work is consistently excellent. The best in the business.',
      rating: 5,
    },
    {
      name: 'Michael Byrne',
      role: 'Business Owner, Galway',
      quote: 'From the initial quote to the final cleanup, everything was handled perfectly. Transparent pricing and a truly skilled team.',
      rating: 5,
    },
  ];

  return (
    <>
      <Helmet>
        <title>Premium Construction & Handyman Services Ireland | Expert Fix</title>
        <meta name="description" content="Trusted by homeowners across Ireland for 20+ years. Professional, reliable, fully insured construction and handyman services. Get a free quote today." />
      </Helmet>

      <Header />

      <main>
        {/* HERO SECTION */}
        <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden pt-20">
          <div className="absolute inset-0">
            <img
              src="https://images.unsplash.com/photo-1702948545240-b44e3c1b86f4"
              alt="Premium construction and renovation"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/90 via-background/80 to-background" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="max-w-4xl mx-auto"
            >
              <div className="inline-flex items-center space-x-2 bg-primary/20 border border-primary/30 rounded-full px-4 py-2 mb-8 backdrop-blur-sm">
                <Shield className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-primary tracking-wide uppercase">Ireland's Premier Service</span>
              </div>
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 text-balance leading-tight">
                Premium Construction & <span className="text-primary">Handyman Services</span> in Ireland
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-3xl mx-auto leading-relaxed font-light">
                Trusted by homeowners across Ireland for 20+ years. Professional, reliable, fully insured.
              </p>
              <div className="flex flex-col sm:flex-row gap-5 justify-center items-center">
                <Link to="/contact" className="w-full sm:w-auto">
                  <Button size="lg" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground text-lg px-10 py-7 rounded-xl transition-all duration-300 shadow-lg shadow-primary/20 hover:shadow-primary/40 active:scale-[0.98] font-semibold">
                    Get Free Quote
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </Link>
                <a href="https://wa.me/353874919556" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto">
                  <Button size="lg" variant="outline" className="w-full bg-foreground text-background hover:bg-foreground/90 border-none text-lg px-10 py-7 rounded-xl transition-all duration-300 shadow-lg active:scale-[0.98] font-semibold">
                    <MessageCircle className="mr-2 w-5 h-5" />
                    Message on WhatsApp
                  </Button>
                </a>
              </div>
            </motion.div>
          </div>
        </section>

        {/* TRUST BAR */}
        <section className="bg-card border-y border-primary/10 py-8 relative z-20 -mt-1">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-4 divide-x-0 md:divide-x divide-primary/20">
              {trustElements.map((item, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex flex-col items-center justify-center text-center px-4"
                >
                  <item.icon className="w-8 h-8 text-primary mb-3" />
                  <span className="text-sm md:text-base font-semibold text-foreground">{item.text}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* SERVICES PREVIEW */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
              <div className="max-w-2xl">
                <h2 className="text-sm font-bold text-primary tracking-widest uppercase mb-3">Our Expertise</h2>
                <h3 className="text-4xl md:text-5xl font-bold text-foreground text-balance leading-tight">
                  Premium Services for Your Property
                </h3>
              </div>
              <Link to="/services">
                <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground px-8 py-6 rounded-xl font-semibold transition-all duration-300">
                  View All Services
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {topServices.map((service, index) => (
                <ServiceCard key={service.title} {...service} index={index} />
              ))}
            </div>
          </div>
        </section>

        {/* WHY CHOOSE US */}
        <section className="py-24 bg-card relative overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-primary/5 rounded-l-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center mb-16">
              <h2 className="text-sm font-bold text-primary tracking-widest uppercase mb-3">The Expert Fix Difference</h2>
              <h3 className="text-4xl md:text-5xl font-bold text-foreground text-balance leading-tight">
                Why Choose Us
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 justify-center">
              {whyChooseUs.map((reason, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className={`bg-background p-8 rounded-2xl border border-primary/10 hover:border-primary/30 transition-colors shadow-lg ${index === 3 ? 'lg:col-start-1 lg:col-end-2 lg:translate-x-1/2' : ''} ${index === 4 ? 'lg:col-start-2 lg:col-end-3 lg:translate-x-1/2' : ''}`}
                >
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
                    <CheckCircle className="w-6 h-6 text-primary" />
                  </div>
                  <h4 className="text-xl font-bold text-foreground mb-3">{reason.title}</h4>
                  <p className="text-muted-foreground leading-relaxed">{reason.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* TESTIMONIALS */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-sm font-bold text-primary tracking-widest uppercase mb-3">Client Success</h2>
              <h3 className="text-4xl md:text-5xl font-bold text-foreground text-balance leading-tight">
                Trusted Across Ireland
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <TestimonialCard key={index} {...testimonial} index={index} />
              ))}
            </div>
          </div>
        </section>

        {/* CONTACT SECTION */}
        <section className="py-24 bg-card border-t border-primary/10">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-foreground mb-4 text-balance">
                Ready to start your project?
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Get your free quote in 24 hours. Fill out the form below.
              </p>
            </div>

            <div className="bg-background p-8 md:p-10 rounded-2xl shadow-2xl border border-primary/20">
              <ContactForm />
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default HomePage;